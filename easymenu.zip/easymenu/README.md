# Easy Menu
> Instant Online Menu for Businesses
------------------------------------------------------------------

Title     : Easy Menu  
Version   : 1.0  
Build     : 0.13  
Author    : Techie Joe @ Tidloo Digital Inc.  
Publisher : Tidloo Digital Inc  

WEBSITE   : https://easymenu.com/  

AUTHOR    : https://github.com/techie-joe/  

------------------------------------------------------------------

EasyMenu simplifies menu creation, enabling businesses
to craft sleek, professional online menus in minutes,
with no coding or design required.

Suitable for businesses of all kinds - cafes, bakeries,
restaurants, shops, service providers, and more.
Simply configure your preferences, and you're ready to go!

------------------------------------------------------------------

Copyright (c) 2025 - Techie Joe @ Tidloo Digital Inc.